fileID = fopen('C:\Users\Kre�imir\Desktop\Ring Modulator\ring_mod.h','w');
fprintf(fileID,'#ifndef ring_mod\r\n');
fprintf(fileID,'#define ring_mod\r\n');
fprintf(fileID,'\r\n');
fprintf(fileID,'extern const float diode[2][513];\r\n');
fprintf(fileID,'\r\n');
fprintf(fileID,'#endif');
fclose(fileID);

test_diode;
fileID = fopen('C:\Users\Kre�imir\Desktop\Ring Modulator\ring_mod.c','w');
fprintf(fileID,'"#include ring_mod.h"\r\n');
fprintf(fileID,'const float diode[2][513] = {');
buffer = 24;
for index = 1:2
    for index2 = 1:513
        if(diode2(index2,index)~=0)
            numberLength = floor(log10(diode2(index2,index)))+3;
            buffer = buffer + numberLength;
        else
            buffer = buffer + 1;
        end;
        if(buffer > 1022)
            fprintf(fileID,'\r\n');
            buffer = numberLength;
        end;
        if(index ~= 2 || index2 ~= 513)
            fprintf(fileID,' %d,',diode2(index2, index));
        else
            fprintf(fileID,' %d',diode2(index2, index));
        end;
    end;
end;
fprintf(fileID, '\r\n');
fprintf(fileID,'};');
fclose(fileID);
