clear all;
close all;
vb = 0.5;
vl = 0.8;
h = 1.0;
t = -1+(1/512):1/512:1;
samples = 1024;
v = zeros(samples,1);
value = zeros(samples,1);
diode = zeros(samples/2+1,2);
for i=1:samples
  
  v(i) = (i - samples/2) / (samples/2);
  v(i) = abs(v(i));
 
  if (v(i) <= vb)
    value(i) = 0;
  elseif ((vb < v(i)) && (v(i) <= vl))
    value(i) = h * ((power(v(i) - vb, 2)) / (2 * vl - 2 * vb));
  else
    value(i) = h * v(i) - h * vl + (h * (power(vl - vb, 2) / (2 * vl - 2 * vb)));
  end;
end;
for i=512:1024
    diode(i-511,1) = v(i);
    diode(i-511,2) = value(i);
end;
diode2 = diode .* 32768;
diode2 = round(diode2);