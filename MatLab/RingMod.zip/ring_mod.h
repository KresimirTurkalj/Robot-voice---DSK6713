#ifndef ring_mod
#define ring_mod

extern const float diode[2][513];

#endif